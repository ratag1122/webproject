<?php include "includes/admin_header.php"; ?>

<div id="wrapper">

    <?php include "includes/admin_navigation.php"; ?>

    <div id="page-wrapper">

        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Absences Management
                        <small><?php echo $_SESSION['username']; ?></small>
                    </h1>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <?php
                    include "../includes/db.php"; 
                    $query = "SELECT * FROM absences";  
                    $result = mysqli_query($connection, $query);

                    if (!$result) {
                        die("Query Failed: " . mysqli_error($connection));
                    }
                    ?>

                    <h2 class="page-header">All Absences</h2>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Course Name</th>
                                <th>Absences</th>
                                <th>Date</th>
                                <th>Attachment</th>
                                <th>Status</th>
                                <th>Accept</th>
                                <th>Reject</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_assoc($result)) {
                                $id = $row['id'];
                                $student_name = $row['student_name'];
                                $course_name = $row['course_name'];
                                $absences = $row['absences'];
                                $date = $row['date'];
                                $attachment = $row['attachment'];
                                $status = $row['status'];
                            ?>
                                <tr>
                                    <td><?php echo $student_name; ?></td>
                                    <td><?php echo $course_name; ?></td>
                                    <td><?php echo $absences; ?></td>
                                    <td><?php echo $date; ?></td>
                                    <td>
                                        <?php if ($attachment): ?>
                                            <a href="uploads/<?php echo $attachment; ?>" target="_blank">View Attachment</a>
                                        <?php else: ?>
                                            No attachment
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo ucfirst($status); ?></td>
                                    <td>
                                        <?php if ($status == 'pending'): ?>
                                            <a href="accept_absence.php?id=<?php echo $id; ?>&action=accept" class="btn btn-success">Accept</a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($status == 'pending'): ?>
                                            <a href="accept_absence.php?id=<?php echo $id; ?>&action=reject" class="btn btn-danger">Reject</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </div>

</div>

<?php include "includes/admin_footer.php"; ?>
