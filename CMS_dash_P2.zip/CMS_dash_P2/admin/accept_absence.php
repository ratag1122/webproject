<?php
include "../includes/db.php";

if (isset($_GET['id']) && isset($_GET['action'])) {
    $absence_id = $_GET['id'];
    $action = $_GET['action'];

    if ($action == 'accept' || $action == 'reject') {
        $status = ($action == 'accept') ? 'accepted' : 'rejected';

        $queryUpdate = "UPDATE absences SET status = ? WHERE id = ?";
        $stmtUpdate = mysqli_prepare($connection, $queryUpdate);
        mysqli_stmt_bind_param($stmtUpdate, "si", $status, $absence_id);

        if (mysqli_stmt_execute($stmtUpdate)) {
            header("Location: absences.php");
            exit();
        } else {
            echo "Error: " . mysqli_error($connection);
        }

        mysqli_stmt_close($stmtUpdate);
    } else {
        echo "Invalid action.";
    }
} else {
    echo "No absence ID or action provided.";
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accept/Reject Absence</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #212020;
            padding: 10px 20px;
            color: white;
        }
        header h1 {
            margin: 0;
        }
        main {
            padding: 20px;
            text-align: center;
        }
        .message {
            margin: 20px auto;
            padding: 10px;
            border-radius: 5px;
            width: 50%;
            font-weight: bold;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        table {
            width: 60%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #212020;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .form-buttons {
            margin-top: 20px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button.reject {
            background-color: #dc3545;
        }
        button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<header>
    <h1>Manage Absence for <?php echo $student_name; ?> - <?php echo $course_name; ?></h1>
</header>

<main>
    <h2>Absence Details</h2>
    <table>
        <tr>
            <th>Student Name</th>
            <td><?php echo $student_name; ?></td>
        </tr>
        <tr>
            <th>Course Name</th>
            <td><?php echo $course_name; ?></td>
        </tr>
        <tr>
            <th>Absences</th>
            <td><?php echo $absences; ?></td>
        </tr>
        <tr>
            <th>Reason</th>
            <td><?php echo $reason; ?></td>
        </tr>
        <tr>
            <th>Date</th>
            <td><?php echo $date; ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo $status; ?></td>
        </tr>
    </table>

    <div class="form-buttons">
        <form method="POST" action="">
            <button type="submit" name="accept">Accept</button>
            <button type="submit" name="reject" class="reject">Reject</button>
        </form>
    </div>
</main>

</body>
</html>
