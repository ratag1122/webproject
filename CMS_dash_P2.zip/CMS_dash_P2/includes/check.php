<?php
session_start();
include 'header.php';
include 'db.php'; 
 



if (!isset($_SESSION['verified']) || $_SESSION['verified'] !== true) {
 
    header("Location: check.php");
    exit();
}


$query = "SELECT Course_Name, Credit_Hours, Course_Instructor, Building FROM `student schedule`";
$result = mysqli_query($connection, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($connection));
}
?> 
 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Schedule</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            align-items: center;
            background-color: #333;
            color: white;
            padding: 10px 20px;
        }
        header img {
            height: 50px;
            margin-right: 10px;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.png" alt="Logo">
        <h1>Student Schedule</h1>
    </header>
    <table>
        <thead>
            <tr>
                <th>Course Name</th>
                <th>Credit Hours</th>
                <th>Course Instructor</th>
                <th>Building</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['Course_Name']; ?></td>
                <td><?php echo $row['Credit_Hours']; ?></td>
                <td><?php echo $row['Course_Instructor']; ?></td>
                <td><?php echo $row['Building']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>