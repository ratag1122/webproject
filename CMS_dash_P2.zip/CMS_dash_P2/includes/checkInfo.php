<?php
$host = 'localhost'; 
$dbname = 'cms';
$username = 'root';
$password = ''; 

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'] ?? '';
    $student_password = $_POST['student_password'] ?? '';

    $student_id = trim($student_id);
    $student_password = trim($student_password);

    if (!empty($student_id) && !empty($student_password)) {
        $query = "SELECT * FROM students WHERE students_id = ? AND students_password = ?";
        $stmt = mysqli_prepare($conn, $query);

        mysqli_stmt_bind_param($stmt, "is", $student_id, $student_password);

        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            header('Location: student.php');
            exit;
        } else {
            $error_message = "Incorrect Student ID or Password!";
        }

        mysqli_stmt_close($stmt);
    } else {
        $error_message = "Wrong entry!";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login to Your Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            align-items: center;
            background-color: #212020;
            padding: 10px 20px;
            color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        header img {
            width: 60px;
            height: auto;
            margin-right: 20px;
        }
        header h1 {
            font-size: 20px;
            margin: 0;
            text-align: center;
        }
        main {
            text-align: center;
            padding: 20px;
        }
        .form-container {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: white;
            font-size: 24px;
            text-align: center;
        }
        label {
            font-size: 14px;
            margin-bottom: 8px;
            display: block;
            text-align: left;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #212020;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #333;
        }
        .error-message {
            color: red;
            font-size: 14px;
            margin: 10px 0;
        }
        .a {
            text-decoration: none;
            color: white;
            margin: 10px 0;
            padding: 10px;
        }
        .home-btn {
            position: absolute;
            right: 10px;   
            text-decoration: none;
            color: gray;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
        }
        .home-btn:hover {
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <h1>Login to Your Information</h1>
        <a href="../index.php" class="home-btn">Home Page</a>
    </header>
    
    <main>
        <div class="form-container">
            <?php if (!empty($error_message)): ?>
                <p class="error-message"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <form method="POST" action="checkInfo.php">
                <label for="student_id">Student ID:</label>
                <input type="text" id="student_id" name="student_id" required><br><br>

                <label for="student_password">Password:</label>
                <input type="password" id="student_password" name="student_password" required><br><br>

                <button type="submit">Submit</button>
            </form>
        </div>
    </main>
</body>
</html>

<?php 
include "footer.php"; 
?>
