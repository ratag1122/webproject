<!-- Footer -->
<footer>
    <div class="row">
        <div class="col-md-4">
            <h5>Stanford University</h5>
            <p>Stanford, California 94305</p>
        </div>
        <div class="col-md-4">
            <h5>Quick Links</h5>
            <ul>
                <li><a href="#">Admissions</a></li>
                <li><a href="#">Apply Now</a></li>
                <li><a href="#">Faculty Positions</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
        <div class="col-md-4">
            <h5>Social Media</h5>
            <ul class="social-media-links">
                <li><a href="#"><i class="fa fa-facebook"></i> Facebook</a></li>
                <li><a href="#"><i class="fa fa-twitter"></i> Twitter</a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i> LinkedIn</a></li>
                <li><a href="#"><i class="fa fa-instagram"></i> Instagram</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <p>&copy; 2024 Stanford University. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Internal CSS for Footer -->
<style>
footer {
    background-color: black; /* Gray background */
    color: #fff; /* White text */
    padding: 40px 0;
    font-size: 14px;
    position: relative;
    bottom: 0;
    width: 100%;
    margin: 0; /* Remove any default margin */
}

footer h5 {
    font-weight: bold;
    color: #fff;
    text-transform: uppercase;
}

footer ul {
    list-style: none;
    padding: 0;
}

footer ul li {
    margin: 10px 0;
}

footer a {
    color: #fff;
    text-decoration: none;
}

footer a:hover {
    color: #f39c12;
}

footer .social-media-links {
    padding-left: 0;
}

footer .social-media-links li {
    display: inline-block;
    margin-right: 15px;
}

footer .social-media-links i {
    margin-right: 8px;
}
</style>
