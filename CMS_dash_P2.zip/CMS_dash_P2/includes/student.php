<?php  
include "header.php";  
include "db.php";    

$success_message = '';
$error_message = '';
$student_id = ''; 
$student_info = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    $student_id = mysqli_real_escape_string($connection, $_POST['student_id']);
    $queryStudent = "SELECT students_name, students_gpa, students_academic_year FROM students WHERE students_id = ?";
    $stmt = mysqli_prepare($connection, $queryStudent);
    mysqli_stmt_bind_param($stmt, "i", $student_id);
    mysqli_stmt_execute($stmt);
    $resultStudent = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($resultStudent) > 0) {
        $student_info = mysqli_fetch_assoc($resultStudent);
    } else {
        $error_message = "Student not found.";
    }
    mysqli_stmt_close($stmt);
}

$querySchedule = "SELECT Course_Name, Credit_Hours, Course_Instructor, Building_1 FROM `student schedule`";
$resultSchedule = mysqli_query($connection, $querySchedule);

$course_query = "SELECT Course_Name FROM `student schedule`";
$course_result = mysqli_query($connection, $course_query);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_name'], $_POST['course_name'], $_POST['absences'], $_POST['reason'], $_POST['absence_date'])) {
    $student_name = mysqli_real_escape_string($connection, $_POST['student_name']);
    $course_name = mysqli_real_escape_string($connection, $_POST['course_name']);
    $absences = (int)$_POST['absences'];
    $reason = mysqli_real_escape_string($connection, $_POST['reason']);
    $absence_date = $_POST['absence_date'];
    $attachment = '';

    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ .'/../admin/uploads/';
        $attachment = basename($_FILES['attachment']['name']);
        $target_file = $upload_dir . $attachment;

        if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file)) {
            $error_message = "Failed to upload file.";
        }
    }

    $queryInsertAbsence = "INSERT INTO absences (student_name, course_name, absences, reason, date, attachment) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($connection, $queryInsertAbsence);
    mysqli_stmt_bind_param($stmt, "ssisss", $student_name, $course_name, $absences, $reason, $absence_date, $attachment);

    if (mysqli_stmt_execute($stmt)) {
        $success_message = "Absence submitted successfully.";
    } else {
        $error_message = "Failed to submit absence.";
    }
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Absence</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            align-items: center;
            background-color: #212020;
            padding: 10px 20px;
            color: white;
        }
        header img {
            width: 60px;
            height: auto;
            margin-right: 20px;
        }
        header h1 {
            font-size: 20px;
            margin: 0;
        }
        main {
            padding: 20px;
            text-align: center;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #212020;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .btn {
            display: inline-block;
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }
        form {
            margin: 20px auto;
            width: 50%;
        }
        input, select, button, textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        .message {
            margin: 20px auto;
            padding: 10px;
            border-radius: 5px;
            width: 50%;
            font-weight: bold;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .home-btn {
            position: absolute;
            right: 10px;   
            text-decoration: none;
            color: gray;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
        }
        .home-btn:hover {
            color: white;
        }
    </style>
</head>
<body>
<header> 
    <img src="../images/Seal_of_Leland_Stanford_Junior_University.svg.png" alt="Image description">
    <h1>Student Info and Absence Submission</h1>    
    <a href="../index.php" class="home-btn">Home Page</a>
</header>
<main>
    <?php if (!empty($error_message)): ?>
        <div class="message error"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <?php if (!empty($success_message)): ?>
        <div class="message success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    <?php if (!$student_info): ?>
        <h2>Enter Student ID</h2>
        <form method="POST" action="">
            <input type="text" name="student_id" placeholder="Enter Student ID" value="<?php echo htmlspecialchars($student_id); ?>" required>
            <button type="submit">Show Info</button>
        </form>
    <?php endif; ?>
    <?php if ($student_info): ?>
        <h2>Student Information</h2>
        <table>
            <tr>
                <th>Name</th>
                <td><?php echo $student_info['students_name']; ?></td>
            </tr>
            <tr>
                <th>GPA</th>
                <td><?php echo $student_info['students_gpa']; ?></td>
            </tr>
            <tr>
                <th>Academic Year</th>
                <td><?php echo $student_info['students_academic_year']; ?></td>
            </tr>
        </table>
        <h2>Student Schedule</h2>
        <table>
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Credit Hours</th>
                    <th>Course Instructor</th>
                    <th>Building</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($resultSchedule)): ?>
                    <tr>
                        <td><?php echo $row['Course_Name']; ?></td>
                        <td><?php echo $row['Credit_Hours']; ?></td>
                        <td><?php echo $row['Course_Instructor']; ?></td>
                        <td><?php echo $row['Building_1']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <h2>Submit Absence</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="text" name="student_name" value="<?php echo $student_info['students_name']; ?>" readonly>
            <select name="course_name" required>
                <option value="">Select Course</option>
                <?php while ($course_row = mysqli_fetch_assoc($course_result)): ?>
                    <option value="<?php echo $course_row['Course_Name']; ?>">
                        <?php echo $course_row['Course_Name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <input type="number" name="absences" placeholder="Number of Absences" min="0" required>
            <textarea name="reason" placeholder="Reason for Absence" required></textarea>
            <input type="date" name="absence_date" placeholder="Absence Date" required>
            <input type="file" name="attachment" placeholder="Attach File">
            <button type="submit">Submit Absence</button>
        </form>
    <?php endif; ?>
</main>
</body>
</html>
<?php 
mysqli_close($connection);
?>
