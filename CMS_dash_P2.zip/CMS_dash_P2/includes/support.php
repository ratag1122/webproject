<?php
$support_questions = [
    "Admissions" => [
        "How to apply?" => "You can apply through the university website under the admissions section.",
        "What are the requirements?" => "You need to have a high school diploma and meet the GPA requirements.",
        "Is there a deadline for application?" => "Yes, the application deadline is June 30th every year."
    ],
    "Registration" => [
        "How do I register for courses?" => "You can register through the student portal after logging in.",
        "Can I change my courses later?" => "Yes, you can change courses during the add/drop period at the beginning of the semester.",
        "How do I drop a course?" => "Go to the registration section in the student portal and select the course you want to drop."
    ],
    "Grades" => [
        "Can I appeal a grade?" => "Yes, you can appeal by submitting a request to the registrar's office.",
        "How do I check my grades?" => "Log into your student portal and go to the grades section.",
        "What is the grading system?" => "We use a 4.0 scale, with A being the highest grade."
    ],
    "Schedule" => [
        "Where can I find my class schedule?" => "Your class schedule is available in the student portal under the 'My Classes' section.",
        "How do I reschedule a class?" => "You cannot reschedule classes directly, but you can drop and add classes during the specified periods.",
        "What happens if I miss a class?" => "You are responsible for catching up on missed lectures by reviewing the course materials or contacting your professor."
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            text-align: center;
            margin-top: 30px;
            font-size: 2.5em;
            color: black;
        }

        .faq-section {
            background-color: #ffffff;
            padding: 20px;
            margin: 20px auto;
            width: 80%;
            max-width: 600px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .faq-category-button {
            background-color: #5A5A5A;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 95%;
            text-align: left;
            font-size: 1.1em;
            cursor: pointer;
            border-radius: 8px;
            margin-bottom: 10px;
            transition: background-color 0.3s;
        }

        .faq-category-button:hover {
            background-color: #3a3a3a;
        }

        .faq-questions {
            display: none;
            padding-left: 20px;
            margin-top: 10px;
        }

        .faq-question-button {
            background-color: transparent;
            color: #5A5A5A;
            border: none;
            padding: 10px 20px;
            width: 100%;
            text-align: left;
            font-size: 1.1em;
            cursor: pointer;
            margin-bottom: 5px;
        }

        .faq-question-button:hover {
            background-color: transparent;
            text-decoration: underline;
        }

        .faq-answer {
            display: none;
            padding-left: 20px;
            margin-top: 5px;
        }
        .footer {
            background-color: black;
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
        }

        .footer p {
            margin: 5px;
        }

        .footer a {
            color: white;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .btn {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Support</h1>

    
    <div class="faq-section">
        <h2>FAQs</h2>

        <?php
        foreach ($support_questions as $category => $questions) {
            echo "<button class='faq-category-button' onclick='toggleQuestions(\"$category\")'>$category</button>";
            echo "<div id='$category' class='faq-questions'>";
            foreach ($questions as $question => $answer) {
                echo "<button class='faq-question-button' onclick='toggleAnswer(\"$category\", \"$question\")'>$question</button>";
                echo "<div id='$category-$question' class='faq-answer'><p>$answer</p></div>";
            }
            echo "</div>";
        }
        ?>

    </div>

   
    <div class="footer">
    <p>Email: <a href="mailto:support@Stanford.com">support@Stanford.com</a></p>
        <p>Phone: <a href="tel:+1234567890">+1234567890</a></p>
    </div>

    <a href="../index.php" class="btn">Back</a>

    <script>
        
        function toggleQuestions(category) {
            var questionsDiv = document.getElementById(category);
            if (questionsDiv.style.display === "none" || questionsDiv.style.display === "") {
                questionsDiv.style.display = "block";
            } else {
                questionsDiv.style.display = "none";
            }
        }

        
        function toggleAnswer(category, question) {
            var answerDiv = document.getElementById(category + "-" + question);
            if (answerDiv.style.display === "none" || answerDiv.style.display === "") {
                answerDiv.style.display = "block";
            } else {
                answerDiv.style.display = "none";
            }
        }
    </script>

</body>
</html>